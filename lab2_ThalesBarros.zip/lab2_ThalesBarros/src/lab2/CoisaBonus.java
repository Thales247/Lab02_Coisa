package lab2;

public class CoisaBonus {

}
