package lab2;

public class Resumo {
	
	private String resumo;
	private String tema;
	
	public Resumo(String resumo, String tema) {
		this.resumo = resumo;
		this.tema = tema;
	}
	
	public String getResumo() {
		return this.resumo;
	}
	
	public String getTema() {
		return this.tema;
	}
}
