package lab2;

import java.util.Locale;

/**
 * Classe responsável pela implementação do registro do tempo gasto online para se dedicar
 * a uma disciplina.
 *
 * @author Thales Barros - 121110595
 *
 */
public class RegistroTempoOnline {

    private String nomeDaDisciplina;
    private int registroTempoOnline;
    private int tempoOnlineEsperado;

    /**
     * Constroi um registro de tempo online a partir do nome da disciplina.
     * cada registro de tempo online começa com o campo de tempo gasto online como nulo.
     * e por padrão o tempo online esperado se inicia com 120.
     *
     * @param nomeDaDisciplina o nome da disciplina
     */
    public RegistroTempoOnline(String nomeDaDisciplina) {
        this.nomeDaDisciplina = nomeDaDisciplina;
        this.registroTempoOnline = 0;
        this.tempoOnlineEsperado = 120;
    }
    /**
     * Constroi um registro de tempo online a partir do nome da disciplina e do tempo online esperado.
     * Cada registro de tempo online começa com o campo de tempo gasto online como nulo.
     *
     * @param nomeDaDisciplina o nome da disciplina
     * @param tempoOnlineEsperado a quantidade de horas online esperada para a disciplina
     */
    public RegistroTempoOnline(String nomeDaDisciplina, int tempoOnlineEsperado) {
        this.nomeDaDisciplina = nomeDaDisciplina;
        this.registroTempoOnline = 0;
        this.tempoOnlineEsperado = tempoOnlineEsperado;
    }
    /**
     * aDICIONA A QUANTIDADE DE TEMPO GASTO ONLINE.
     *
     * @Param tempo a quantidade de tempo online gasto
     */
    public void adicionaTempoOnline(int tempo) {
        this.registroTempoOnline += tempo;
    }
    /**
     * verifica se o aluno atingiu o tempo esperado para a disciplina.
     *
     * @return um booleano indicando se atingiu a meta do tempo online esperado ou não
     */
    public boolean atingiuMetaTempoOnline() {
        if(this.registroTempoOnline >= this.tempoOnlineEsperado) {
            return true;
        } else {
            return false;
        }
    }
    /**
     * Retorna a String que representa o registro de tempo online. A representação segue o
     * formato NOME DA DISCIPLINA = REGISTRO TEMPO ONLINE - TEMPO ONLINE ESPERADO.
     *
     * @return a representação em string do registro de tempo online
     */
    public String toString() {
        return this.nomeDaDisciplina + " " + this.registroTempoOnline + "/" + this.tempoOnlineEsperado;
    }
}

