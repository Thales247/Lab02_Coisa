package lab2;

/**
 * Classe responsável pelo registro de resumos de um aluno.
 *
 * @author Thales Barros - 121110595
 *
 */
public class RegistroResumos {

    private int numeroDeResumos;
    private Resumo[] resumo;
    private int contador;
    
    public RegistroResumos(int numeroDeResumos) {
    	this.resumo = new Resumo[numeroDeResumos];
    	this.numeroDeResumos = 0;
    	contador = 0;
    
    }

	public void adiciona(String tema, String resumo) {
		if(this.numeroDeResumos > this.resumo.length) {
			this.numeroDeResumos = 0;
		}
		this.resumo[this.numeroDeResumos++] = new Resumo(resumo, tema);
		contador += 1;
	}
	
	public String[] pegaResumos() {
		String[] resumosCadastrados = new String[conta()];
		int j = 0;
		for(int i = 0; i < this.conta(); i++) {
				resumosCadastrados[j++] = this.resumo[i].getTema() + ": " + this.resumo[i].getResumo();
			
		}
		return resumosCadastrados;
	}

	public int conta() {
		if(contador > this.resumo.length) {
			return this.resumo.length;
		} else {
			return this.contador;
		}
	}

	public String imprimeResumos() {
		String resumos = "";
		resumos += "- " + this.conta() + " resumo(s) cadastrado(s)" + "\n" + "-";
		String temas = "";
		for(int i = 0; i < conta(); i++) {
			if(i == conta() - 1) {
				temas += this.resumo[i].getTema();
			} else {
			temas += this.resumo[i].getTema() +  " | ";  
		}
		}
		return resumos + temas;
	}

	public boolean temResumo(String string) {
		for(int i = 0; i < this.conta(); i++) {
			if(resumo[i].getTema().equals(string)) {
				return true;
			}
		}
		
		return false;
	} 

    
    
    	

}