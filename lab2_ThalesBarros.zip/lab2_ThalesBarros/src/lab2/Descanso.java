/**
 * Classe responsável pela implementação das horas de descanso de um aluno.
 *
 * @author Thales barros - 121110595
 *
 */
package lab2;

public class Descanso {

    private int horasdeDescanso;
    private int numerosDeSemana;
    private String smile;
    private String disposicao;

    /**
     *  Constrói o descanso.
     *  Todo aluno começa com o campo horas de descanso como nulo, os números da semana com o valor 1
     *  e por padrão começa com a disposição cansado.
     *
     */
    public Descanso() {
        this.horasdeDescanso = 0;
        this.numerosDeSemana = 1;
        this.smile = "";
        this.disposicao = "cansado";
    }

    /**
     * Define as horas de descanso do aluno.
     *
     * @param valor as horas de descanso do aluno.
     *
     */
    public void defineHorasDescanso(int valor) {
        this.horasdeDescanso = valor;
        verificaMudancaDeDisposicao();
    }
    /**
     *  Define a quantidade de semanas utilizadas pelo aluno.
     *
     * @param valor a quantidade de semanas utilizadas pelo aluno.
     */
    public void defineNumeroSemanas(int valor) {
        this.numerosDeSemana = valor;
        verificaMudancaDeDisposicao();
    }
    /**
     * Define o smile que representa o sentimento do aluno.
     *
     * @param valor um smile representando o sentimento do aluno.
     */
    public void defineSmile(String valor) {
        this.smile = "-" + valor;
    }
    /**
     * Retorna uma representação do status geral do aluno chamando um método que retorna se o aluno
     * esta cansado ou descansado e adicioando um smile, caso este tenha sido definido pelo aluno.
     *
     * @return uma String representando se o aluno esta cansado ou descansado juntamente com um smile
     * que descreve o seu sentimento caso este tenha sido definido.
     */
    public String getStatusGeral() {
        return estadoDeDescanso() + this.smile;
    }
    /**
     * Retorna uma representação do estado de descanso do aluno.
     *
     * @return uma String representando se o aluno está cansado ou descansado
     */
    private String estadoDeDescanso() {
        if(this.horasdeDescanso / this.numerosDeSemana >= 26) {
            return "descansado";
        } else {
            return "cansado";
        }
}
    /**
     * Verifica se houve uma mundança no estado de disposição do aluno. Se houver uma mundança
     * o método atualiza o seu humor.
     */
    private void verificaMudancaDeDisposicao() {
        String novoDisposicao = estadoDeDescanso();
        if(!this.disposicao.equals(novoDisposicao)) {
            this.disposicao = novoDisposicao;
            this.smile = "";
        }
    }
}
